%% Parameters 
% BOMBARDIER BD700 GLOBAL EXPRESS
% Global 6500
close all
% clear

% Aircraft parameters
W=35000*9.81; %N  % 23691 kg basic operating weight,  45132 kg MTOW
S=94.9; % m^2 wing surface
b=28.7; % m wingspan
operational_ceiling = 15545; % m 
n_max = 2.5; % maximum load factor (civil) 

% Polar data
Polar=load('BD700_polar.txt'); 

% Thrust data
Dati_thrust = load('BD700_thrust.txt');
h_ft = Dati_thrust(2:end, 1); % Height in ft
V_ms = Dati_thrust(1, 2:end); % m/s
Thrust = Dati_thrust(2:end, 2:end); % N
h_m = h_ft * 0.3048; % Height in m

% Drag-rise data
Dati_dragrise = load('dragrise.dat');
Mach_dragrise = Dati_dragrise(1, :); % Mach number
Dragrise = Dati_dragrise(2, :); % Drag-rise

% Parameters 
g = 9.81; % gravitational acceleration
gamma = 1.4; 
R = 8314 / 28.96; % R_universal/MM_air
rho0 = 1.225; % density at h=0m

% Heights 
h_trim = 0; % Trim height
h_turn = 2500; % Turn height
h_glide = 5000; % Start of glide height

% Take-off parameters
h_airport=0; % m airport height
psi=0; % runway inclination
V_in=0; % initial speed ground run
mu_brakes=0.4; % brakes drag coefficent
manetta=0.85; % hypotesis: 85% of thrust for take-off
mu_runway=0.05; % concretre/asphal drag coefficent
dCd_gear=0.05; % landing gear
K_int=0.25; % fowler flaps
K_ind=0.08; % induced drag factor
AR=b^2/S; % aspect ratio
delta_flap=15/360*pi; % flap defelction in rad
angolo_freccia=35/360*2*pi; % sweep angle in rad
Swf_S=0.85; % flapped area/wing surface
Cf_C=0.2; % flap chord/wing chord
Cl_delta_flap=3.75; 
K_primo=0.95;
dCd_2d=0.005; % profile drag increment

%% Trimmed polar

cl=Polar(1, :);
cd=Polar(2, :);

% Exclusion of points beyond stall
[cl_max, i_cl_max]=max(cl); % stall
cl=cl(1:i_cl_max); 
cd=cd(1:i_cl_max);

% Interpolated polar
CL_spline=linspace(cl(1),cl(end),100);
CD_spline=spline(cl, cd, CL_spline);

% Parabolic polar
P=polyfit(CL_spline.^2,CD_spline,1);
K=P(1);
CD0=P(2);

figure(1)
plot(Polar(2, :), Polar(1, :), '^', 'LineWidth', 2);
hold on
plot(CD_spline, CL_spline, 'r', 'LineWidth', 2); 
xlabel('C_D');
ylabel('C_L');
title('Trimmed Polar');
grid on;
hold off;

figure(2)
plot(Polar(2, :), Polar(1, :), '^', 'LineWidth', 2);
hold on
plot(polyval(P,CL_spline.^2), CL_spline, 'g', 'LineWidth', 2);
xlabel('C_D');
ylabel('C_L');
title('Parabolic Polar');
grid on;
hold off;

%% Maximum speed

v_max_temp= 325; % temporary maximum speed

% Thrust interpolation, varies with height and speed
T_interp = @(h, v) interp2(V_ms, h_m, Thrust, v, h, 'spline');

% At h=0: 
[~, dens_0, T_0] = isatm(0); % air density
c_0 = sqrt(gamma * R * T_0); % speed of sound
v_stall_0 = sqrt((W / S) / (0.5 * dens_0 * cl_max));
v_0 = linspace(v_stall_0, v_max_temp, 1000);

Thrust_0 = zeros(size(v_0));
CL_0 = zeros(size(v_0));
CD_0 = zeros(size(v_0));
D_0= zeros(size(v_0));
SET_0 = zeros(size(v_0));

% Tollerance for SET ≈ 0 search 
tolleranza_SET = 1000 / W; 

for i = 1:length(v_0)
    Thrust_0(i)=T_interp(0,v_0(i)); % thrust at h=0
    CL_0(i) = (W / S) / (0.5 * dens_0 * v_0(i)^2); % lift coefficent
    CD_0(i) = spline(cl, cd, CL_0(i)); % drag coefficent
    
    % Mach number
    Mach_0 = v_0(i) / c_0;
    % Drag rise
    if Mach_0 < min(Mach_dragrise)
        Delta_CD = 0; % no drag rise for Mach < Mach_min
    elseif Mach_0 > max(Mach_dragrise)
        Delta_CD = max(Dragrise); % for Mach > Mach_max maximum drag rise 
    else
        Delta_CD = spline(Mach_dragrise, Dragrise, Mach_0); % Interpolation
    end
    
    % Total drag at h=0
    D_0(i) = 0.5 * dens_0 * v_0(i)^2 * S * (CD_0(i) + Delta_CD);
    
    SET_0(i)=(Thrust_0(i)-D_0(i))/W;

    idx_SET_zero = find(abs(SET_0) < tolleranza_SET);
end

v_massima_0=v_0(max(idx_SET_zero)); % maximum speed at h=0

%% Penaud diagram

% Maximum speed used for the graphs
v_massima=v_massima_0*101/100; % m/s

% At the chosen h_trim: 
[~, dens_trim, T_trim] = isatm(h_trim); % air density
c = sqrt(gamma * R * T_trim); % speed of sound
v_stallo_trim = sqrt((W / S) / (0.5 * dens_trim * cl_max));
v_trim = linspace(v_stallo_trim, v_massima, 100);

% Variables 
CL_trim = zeros(size(v_trim));
CD_trim = zeros(size(v_trim));
P_r = zeros(size(v_trim));
P_a = zeros(size(v_trim));
SET = zeros(size(v_trim));
SEP = zeros(size(v_trim));
D = zeros(size(v_trim));
E = zeros(size(v_trim)); % Efficency (C_L / C_D)
F = zeros(size(v_trim)); % F = E * sqrt(C_L)
G = zeros(size(v_trim)); % G = E / sqrt(C_L)

Thrust_trim = arrayfun(@(v) T_interp(h_trim, v), v_trim);

for i = 1:length(v_trim)
    Thrust_trim(i)=T_interp(h_trim,v_trim(i)); % thrust at h_trim
    CL_trim(i) = (W / S) / (0.5 * dens_trim * v_trim(i)^2); % lift coefficent
    CD_trim(i) = spline(cl, cd, CL_trim(i)); % drag coefficent
    
    % Mach number
    Mach_turn = v_trim(i) / c;
    % Drag rise
    if Mach_turn < min(Mach_dragrise)
        Delta_CD = 0; % no drag rise for Mach < Mach_min
    elseif Mach_turn > max(Mach_dragrise)
        Delta_CD = max(Dragrise); % for Mach > Mach_max maximum drag rise 
    else
        Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn); % Interpolation
    end
    
    % Total drag
    D(i) = 0.5 * dens_trim * v_trim(i)^2 * S * (CD_trim(i) + Delta_CD);
    
    % Required power
    P_r(i) = D(i) * v_trim(i);
    
    % Available power
    P_a(i)=Thrust_trim(i)*v_trim(i);

    % E, F, G
    E(i) = CL_trim(i) / (CD_trim(i) + Delta_CD); % Efficiency
    F(i) = E(i) * sqrt(CL_trim(i)); % F = E * sqrt(C_L)
    G(i) = E(i) / sqrt(CL_trim(i)); % G = E / sqrt(C_L)
    
    % SET, SEP
    SET(i)=(Thrust_trim(i)-D(i))/W;
    SEP(i)=(P_a(i)-P_r(i))/W;
end

% Maximum performance points
[E_max, idx_E] = max(E); 
[F_max, idx_F] = max(F); 
[G_max, idx_G] = max(G); 

% Required thrust
figure(3);
plot(v_trim, D, '-b', 'LineWidth', 2, 'DisplayName', sprintf('Thrust required')); % drag curve
hold on;
plot(v_trim, Thrust_trim, '--r', 'LineWidth', 2, 'DisplayName', sprintf('Thrust available'));
plot(v_trim(1), D(1), 'ko', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('Stall'));
plot(v_trim(idx_E), D(idx_E), 'c^', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('E_{max} (%.2f)', E_max)); % E_max point
plot(v_trim(idx_F), D(idx_F), 'gd', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('F_{max} (%.2f)', F_max)); % F_max point
plot(v_trim(idx_G), D(idx_G), 'mx', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('G_{max} (%.2f)', G_max)); % G_max point
xlim([0, max(v_trim)*1.05]);
xlabel('TAS [m/s]');
ylabel('D [N]');
title(['Penaud diagram (thrust) at ',num2str(h_trim),'m']);
grid on;
legend('Location', 'best');
hold off;

% Required power
figure(4);
plot(v_trim, P_r, '-b', 'LineWidth', 2, 'DisplayName', sprintf('Power required')); 
hold on
plot(v_trim, P_a, '--r', 'LineWidth', 2, 'DisplayName', sprintf('Power available'));
plot(v_trim(1), P_r(1), 'ko', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('Stall'));
plot(v_trim(idx_E), P_r(idx_E), 'c^', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('E_{max} (%.2f)', E_max)); 
plot(v_trim(idx_F), P_r(idx_F), 'gd', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('F_{max} (%.2f)', F_max)); 
plot(v_trim(idx_G), P_r(idx_G), 'mx', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('G_{max} (%.2f)', G_max)); 
xlim([0, max(v_trim)]*1.05);
xlabel('TAS [m/s]');
ylabel('Pr [N]');
title(['Penaud diagram (power) at ',num2str(h_trim),'m']);
grid on;
legend('Location', 'best');
hold off;

% SET
figure(5)
x_lim = [min(v_trim), max(v_trim)]; % x axis limits
y_lim = [min(SET), max(SET)]; % y axis limits
fill([x_lim(1), x_lim(2), x_lim(2), x_lim(1)], [0, 0, y_lim(2), y_lim(2)], [0.9, 1, 0.9], 'EdgeColor', 'none'); % green area for SET>0
hold on
fill([x_lim(1), x_lim(2), x_lim(2), x_lim(1)], [y_lim(1), y_lim(1), 0, 0], [1, 0.9, 0.9], 'EdgeColor', 'none'); % red area for SET<0
plot(v_trim, SET, '-b', 'LineWidth', 2, 'DisplayName', 'SET'); % SET curve
yline(0, 'k--', 'LineWidth', 1); % SET = 0
xlim([min(v_trim), max(v_trim)]);
ylim([min(SET), max(SET)]);
xlabel('v [m/s]');
ylabel('SET ');
title(['SET at ',num2str(h_trim),'m']);
grid on;
hold off

% SEP
figure(6)
x_lim = [min(v_trim), max(v_trim)]; 
y_lim = [min(SEP), max(SEP)]; 
fill([x_lim(1), x_lim(2), x_lim(2), x_lim(1)], [0, 0, y_lim(2), y_lim(2)], [0.9, 1, 0.9], 'EdgeColor', 'none'); 
hold on
fill([x_lim(1), x_lim(2), x_lim(2), x_lim(1)], [y_lim(1), y_lim(1), 0, 0], [1, 0.9, 0.9], 'EdgeColor', 'none'); 
plot(v_trim, SEP, '-b', 'LineWidth', 2, 'DisplayName', 'SEP'); % SEP curve
yline(0, 'k--', 'LineWidth', 1); % SEP = 0
xlim([min(v_trim), max(v_trim)]);
ylim([min(SEP), max(SEP)]);
xlabel('v [m/s]');
ylabel('SEP [W/N]');
title(['SEP at ',num2str(h_trim),'m']);
grid on;
hold off

%% Penaud diagram EAS

% TAS -> EAS conversion
v_trim_eas = v_trim .* sqrt(dens_trim / rho0);

% Variables 
CL_trim = zeros(size(v_trim_eas));
CD_trim = zeros(size(v_trim_eas));
P_r = zeros(size(v_trim_eas));
P_a = zeros(size(v_trim_eas));
SET = zeros(size(v_trim_eas));
SEP = zeros(size(v_trim_eas));
D = zeros(size(v_trim_eas));
E = zeros(size(v_trim_eas)); % Efficency (C_L / C_D)
F = zeros(size(v_trim_eas)); % F = E * sqrt(C_L)
G = zeros(size(v_trim_eas)); % G = E / sqrt(C_L)

% Thrust interpolation, varies with height and speed
T_interp = @(h, v) interp2(V_ms, h_m, Thrust, v, h, 'spline');
Thrust_trim = arrayfun(@(v) T_interp(h_trim, v), v_trim);
for i = 1:length(v_trim_eas)
    Thrust_trim(i)=T_interp(h_trim,v_trim(i)); % thrust at h_trim
    CL_trim(i) = (W / S) / (0.5 * rho0 * v_trim_eas(i)^2); % lift coefficent
    CD_trim(i) = spline(cl, cd, CL_trim(i)); % drag coefficent
    
    % Mach number
    Mach_turn = v_trim(i) / c;
    % Drag rise
    if Mach_turn < min(Mach_dragrise)
        Delta_CD = 0; % no drag rise for Mach < Mach_min
    elseif Mach_turn > max(Mach_dragrise)
        Delta_CD = max(Dragrise); % for Mach > Mach_max maximum drag rise 
    else
        Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn); % Interpolation
    end
    
    % Total drag
    D(i) = 0.5 * rho0 * v_trim_eas(i)^2 * S * (CD_trim(i) + Delta_CD);
    
    % Required power
    P_r(i) = D(i) * v_trim(i);
    
    % Available power
    P_a(i)=Thrust_trim(i)*v_trim(i);

    % E, F, G
    E(i) = CL_trim(i) / (CD_trim(i) + Delta_CD); % Efficiency
    F(i) = E(i) * sqrt(CL_trim(i)); % F = E * sqrt(C_L)
    G(i) = E(i) / sqrt(CL_trim(i)); % G = E / sqrt(C_L)
    
    % SET, SEP
    SET(i)=(Thrust_trim(i)-D(i))/W;
    SEP(i)=(P_a(i)-P_r(i))/W;
end

% Maximum performance points
[E_max, idx_E] = max(E); 
[F_max, idx_F] = max(F); 
[G_max, idx_G] = max(G); 

% Required thrust
figure(28);
plot(v_trim_eas, D, '-b', 'LineWidth', 2, 'DisplayName', sprintf('Thrust required')); % drag curve
hold on;
plot(v_trim_eas, Thrust_trim, '--r', 'LineWidth', 2, 'DisplayName', sprintf('Thrust available'));
plot(v_trim_eas(1), D(1), 'ko', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('Stall'));
plot(v_trim_eas(idx_E), D(idx_E), 'c^', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('E_{max} (%.2f)', E_max)); % E_max point
plot(v_trim_eas(idx_F), D(idx_F), 'gd', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('F_{max} (%.2f)', F_max)); % F_max point
plot(v_trim_eas(idx_G), D(idx_G), 'mx', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', sprintf('G_{max} (%.2f)', G_max)); % G_max point
xlim([0, max(v_trim_eas)]*1.05);
xlabel('EAS [m/s]');
ylabel('D [N]');
title(['EAS Penaud diagram (thrust) at ',num2str(h_trim),'m']);
grid on;
legend('Location', 'best');
hold off;

%% Absolute ceiling

% Variables
h_min = min(h_m); % Minimum height for search 
h_max = max(h_m); % Maximum height for search
tolleranza = 1; % Tolerance for absolute ceiling (in meters)
h_tangenza = NaN; % absolute ceiling

while (h_max - h_min) > tolleranza
    h_medio = (h_min + h_max) / 2;
    
    % parameters at h_medio
    [~, dens, T] = isatm(h_medio);
    c = sqrt(gamma * R * T);
    v_stallo = sqrt((W / S) / (0.5 * dens * cl_max));

    v_vect = linspace(v_stallo, v_massima, 1000); 
    
    % Thrust and Drag at every speed at h_medio
    T_vals = arrayfun(@(v) T_interp(h_medio, v), v_vect);
    D_vals = zeros(size(v_vect));
    for i = 1:length(v_vect)
        CL = (W / S) / (0.5 * dens * v_vect(i)^2);
        if CL > max(cl) || CL < min(cl)
            D_vals(i) = NaN;
            continue;
        end

        CD = spline(cl, cd, CL);
        Mach_current = v_vect(i) / c;

        if Mach_current < min(Dati_dragrise(1,:))
            Delta_CD = 0;
        elseif Mach_current > max(Dati_dragrise(1,:))
            Delta_CD = max(Dati_dragrise(2,:));
        else
            Delta_CD = spline(Dati_dragrise(1,:), Dati_dragrise(2,:), Mach_turn);
        end

        D_vals(i) = 0.5 * dens * v_vect(i)^2 * S * (CD + Delta_CD);
    end
    
    SET_vals = (T_vals - D_vals) / W;
    max_SET_current = max(SET_vals);

    set_zero_threshold = 1e-4;

    if max_SET_current > set_zero_threshold
    h_min = h_medio; % The absolute ceiling is higher
    else
    h_tangenza = h_medio; 
    h_max = h_medio;      % The absolute ceiling is lower
    end
    
end

%% Climb 

% analyzed heights
h_vect = linspace(0, h_tangenza, 100);

% Variables
v_climb_cell = cell(length(h_vect), 1);
SET_cell = cell(length(h_vect), 1);
SEP_cell = cell(length(h_vect), 1);
v_gamma_max = zeros(length(h_vect), 1);
gamma_max = zeros(length(h_vect), 1);
v_Vv_massima = zeros(length(h_vect), 1);
Vv_massima = zeros(length(h_vect), 1);
SEP_gamma_max = zeros(length(h_vect), 1);

for h_idx = 1:length(h_vect)
    h_current = h_vect(h_idx); % current height
    
    [~, dens_current, T_current] = isatm(h_current);
    c = sqrt(gamma * R * T_current);
    v_stallo_current = sqrt((W / S) / (0.5 * dens_current * cl_max));
    v_current = linspace(v_stallo_current, v_massima, 1000);
    
    % every cell represents a height
    v_climb_cell{h_idx} = v_current; % all the speeds at the current height
    
    % available thrust
    Thrust_current = T_interp(h_current,v_current);
    
    % SET and SEP at the current height
    SET_current = zeros(size(v_current));
    SEP_current = zeros(size(v_current));
    
    for i = 1:length(v_current)
        CL = (W / S) / (0.5 * dens_current * v_current(i)^2);
        CD = spline(cl, cd, CL);
        
        Mach_turn = v_current(i) / c;
        if Mach_turn < min(Mach_dragrise)
            Delta_CD = 0;
        elseif Mach_turn > max(Mach_dragrise)
            Delta_CD = max(Dragrise);
        else
            Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn);
        end
        
        D = 0.5 * dens_current * v_current(i)^2 * S * (CD + Delta_CD);
        P_r = D * v_current(i);
        P_a = Thrust_current(i)*v_current(i);
        
        SET_current(i) = (Thrust_current(i) - D) / W;
        SEP_current(i) = (P_a - P_r) / W;
    end
    
    % Results saved for the final plot
    SET_cell{h_idx} = SET_current*360/(2*pi);
    SEP_cell{h_idx} = SEP_current;
    
    % Research of maximum performance points
    [gamma_max(h_idx), idx_gamma] = max(SET_current*360/(2*pi));
    v_gamma_max(h_idx) = v_current(idx_gamma);
    
    [Vv_massima(h_idx), idx_Vv] = max(SEP_current);
    v_Vv_massima(h_idx) = v_current(idx_Vv);
    SEP_gamma_max(h_idx) = SEP_current(idx_gamma);
end

% Climb angle
figure(7); 
hold on;
for h_idx = 1:length(h_vect)
    plot(v_gamma_max(h_idx), gamma_max(h_idx), 'om', 'MarkerSize', 8, 'LineWidth', 1.5);
    plot(v_climb_cell{h_idx}, max(SET_cell{h_idx}, 0), '-m');
end
xlabel('V [m/s]');
ylabel('Angle of climb [deg]');
title('Angle of climb at different altitudes');
grid on; 
legend('Max angle', 'Location', 'best');
hold off;

% Rate of climb
figure(8); 
hold on;
for h_idx = 1:length(h_vect)
    plot(v_Vv_massima(h_idx), Vv_massima(h_idx), 'sc', 'MarkerSize', 8, 'LineWidth', 1.5);
    plot(v_gamma_max(h_idx), max(SEP_gamma_max(h_idx), 0), 'om', 'MarkerSize', 8, 'LineWidth', 1.5);
    plot(v_climb_cell{h_idx}, max(SEP_cell{h_idx}, 0), '-c');
end
ylim([0, max(Vv_massima)*1.05]);
xlabel('V [m/s]');
ylabel('Rate of climb [m/s]');
title('Rate of climb at different altitudes');
grid on; 
legend({'Max rate', 'Max angle'}, 'Location', 'best');
hold off;

% Climb performance behaviour with height
figure(9);  
hold on;
plot(gamma_max, h_vect, '-m', 'LineWidth', 1.5, 'DisplayName', 'Max angle [deg]');
plot(Vv_massima, h_vect, '-c', 'LineWidth', 1.5, 'DisplayName', 'Max rate [m/s]');
xlabel('Max rate [m/s], Max angle [deg]');
ylabel('h [m]');
title('Climb performance at different altitudes');
legend('Location', 'best', 'NumColumns', 2);
grid on;
hold off;

%% Required climb graphs: angle

h_current = 5000;

[~, dens_current, T_current] = isatm(h_current);
c = sqrt(gamma * R * T_current);
v_stallo_current = sqrt((W / S) / (0.5 * dens_current * cl_max));
v_current = linspace(v_stallo_current, v_massima, 1000);

% TAS -> EAS conversion
v_massima_eas = v_massima .* sqrt(dens_current / rho0);
v_stallo_cuurent_eas = v_stallo_current .* sqrt(dens_current / rho0);
v_current_eas = v_current .* sqrt(dens_current / rho0);
v_climb_cell_eas = v_current_eas;

Thrust_current = T_interp(h_current,v_current);

SET_current = zeros(size(v_current));
SEP_current = zeros(size(v_current));

for i = 1:length(v_current_eas)
    CL = (W / S) / (0.5 * rho0 * v_current_eas(i)^2);
    CD = spline(cl, cd, CL);
    
    Mach_turn = v_current(i) / c;
    if Mach_turn < min(Mach_dragrise)
        Delta_CD = 0;
    elseif Mach_turn > max(Mach_dragrise)
        Delta_CD = max(Dragrise);
    else
        Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn);
    end
    
    D = 0.5 * rho0 * v_current_eas(i)^2 * S * (CD + Delta_CD);
    P_r = D * v_current(i);
    P_a = Thrust_current(i)*v_current(i);
    
    SET_current(i) = (Thrust_current(i) - D) / W;
    SEP_current(i) = (P_a - P_r) / W;
end

SET_cell = SET_current*360/(2*pi);

[gamma_max, idx_gamma] = max(SET_current*360/(2*pi));
v_gamma_max_eas = v_current_eas(idx_gamma);

figure(26); 
hold on;
plot(v_gamma_max_eas, gamma_max, 'om', 'MarkerSize', 8, 'LineWidth', 1.5);
plot(v_climb_cell_eas, max(SET_cell, 0), '-m', 'LineWidth', 2);
xlim([0, v_massima_eas]*1.05);
xlabel('EAS [m/s]');
ylabel('Angle of climb [deg]');
title(['Angle of climb at ',num2str(h_current),'m']);
grid on; 
legend('Max angle', 'Location', 'best');
hold off;

%% Required climb graphs: roc

    h_current = 4500;
    
    [~, dens_current, T_current] = isatm(h_current);
    c = sqrt(gamma * R * T_current);
    v_stallo_current = sqrt((W / S) / (0.5 * dens_current * cl_max));
    v_current = linspace(v_stallo_current, v_massima, 1000);

    v_climb_cell = v_current; 

    Thrust_current = T_interp(h_current,v_current);
    
    SET_current = zeros(size(v_current));
    SEP_current = zeros(size(v_current));
    
    for i = 1:length(v_current)
        CL = (W / S) / (0.5 * dens_current * v_current(i)^2);
        CD = spline(cl, cd, CL);
        
        Mach_turn = v_current(i) / c;
        if Mach_turn < min(Mach_dragrise)
            Delta_CD = 0;
        elseif Mach_turn > max(Mach_dragrise)
            Delta_CD = max(Dragrise);
        else
            Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn);
        end
        
        D = 0.5 * dens_current * v_current(i)^2 * S * (CD + Delta_CD);
        P_r = D * v_current(i);
        P_a = Thrust_current(i)*v_current(i);
        
        SET_current(i) = (Thrust_current(i) - D) / W;
        SEP_current(i) = (P_a - P_r) / W;
    end
    
    SET_cell = SET_current*360/(2*pi);
    SEP_cell = SEP_current;
    
    [gamma_max, idx_gamma] = max(SET_current*360/(2*pi));
    v_gamma_max = v_current(idx_gamma);
    
    [Vv_massima, idx_Vv] = max(SEP_current);
    v_Vv_massima = v_current(idx_Vv);
    SEP_gamma_max = SEP_current(idx_gamma);

figure(27); 
hold on;

plot(v_Vv_massima, Vv_massima, 'sc', 'MarkerSize', 8, 'LineWidth', 1.5);
plot(v_gamma_max, max(SEP_gamma_max, 0), 'om', 'MarkerSize', 8, 'LineWidth', 1.5);
plot(v_climb_cell, max(SEP_cell, 0), '-c', 'LineWidth', 2);
xlim([0, v_massima]*1.05);
xlabel('TAS [m/s]');
ylabel('Rate of climb [m/s]');
title(['Rate of climb at ',num2str(h_current),'m']);
grid on; 
legend({'Max rate', 'Max angle'}, 'Location', 'best');
hold off;

%% Flight envelope

% Variables
h_vect = linspace(0, h_tangenza, 100); 
v_eq1 = zeros(size(h_vect)); % First equilibrium speed
v_eq2 = zeros(size(h_vect)); % Second equilibrium speed
use_stallo = false(size(h_vect)); 
dens_vect = zeros(size(h_vect));
t2c = zeros(size(h_vect));
dt2c = zeros(size(h_vect));
ut2c = zeros(size(h_vect));
udt2c = zeros(size(h_vect));
gradV = zeros(size(h_vect));
v_gamma_max_inv = zeros(size(h_vect)); % speed for maximum angle
v_Vv_massima_inv = zeros(size(h_vect)); % speed for maximum rate 
Vv_massima = zeros(size(h_vect)); % maximum SEP (rate of climb)

% Tollerance for SET ≈ 0 search 
tolleranza_SET = 200 / W; % |T - D| < 200 N

for j = 1:length(h_vect)
    h_j = h_vect(j);
    [~, dens_j, T_j] = isatm(h_j);
    dens_vect(j) = dens_j;
    c = sqrt(gamma * R * T_j);
    v_stallo_j = sqrt((W / S) / (0.5 * dens_j * cl_max));
    v_j = linspace(v_stallo_j, v_massima, 1000);
    Thrust_j = T_interp(h_j, v_j);
    
    SEP_j = zeros(size(v_j));
    D_j = zeros(size(v_j));
    SET_j = zeros(size(v_j));
    
    for i = 1:length(v_j)
        CL_j = (W / S) / (0.5 * dens_j * v_j(i)^2);
        CD_j = spline(cl, cd, CL_j);

        % Drag-rise
        Mach_turn = v_j(i) / c;
        if Mach_turn < min(Mach_dragrise)
            Delta_CD = 0;
        elseif Mach_turn > max(Mach_dragrise)
            Delta_CD = max(Dragrise);
        else
            Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn);
        end
        
        D_j(i) = 0.5 * dens_j * v_j(i)^2 * S * (CD_j + Delta_CD);
        SET_j(i) = (Thrust_j(i) - D_j(i)) / W;
        SEP_j(i) = (Thrust_j(i) * v_j(i) - D_j(i) * v_j(i)) / W;
    end
    
    % Performance points at current height
    [max_SEP_current, idx_Vv] = max(SEP_j);
    Vv_massima(j) = max_SEP_current; % the maxium SEP is saved to calculate the service ceiling 
    v_Vv_massima_inv(j) = v_j(idx_Vv); % maximum rate of climb speed
    
    [~, idx_gamma] = max(SET_j);
    v_gamma_max_inv(j) = v_j(idx_gamma); % maximum angle of climb speed 

    % SET ≈ 0 search 
    idx_SET_zero = find(abs(SET_j) < tolleranza_SET);
    if ~isempty(idx_SET_zero)
        % The first equilibrium point is searched before the absolute ceiling is reached
        limite_inferiore_1 = v_stallo_j;
        limite_superiore_1 = v_Vv_massima_inv(j);
        idx_ramo_1 = idx_SET_zero(v_j(idx_SET_zero) >= limite_inferiore_1 & v_j(idx_SET_zero) <= limite_superiore_1);
        if ~isempty(idx_ramo_1)
            v_eq1(j) = v_j(idx_ramo_1(1)); % propulsive limitation
        else
            v_eq1(j) = v_stallo_j; % aerodynamic limitation
            use_stallo(j) = true;
        end
        
        % The second equilibrium point is searched after the maximum rate of climb speed
        limite_inferiore_2 = v_Vv_massima_inv(j);
        limite_superiore_2 = v_massima;
        idx_ramo_2 = idx_SET_zero(v_j(idx_SET_zero) >= limite_inferiore_2 & v_j(idx_SET_zero) <= limite_superiore_2);
        if ~isempty(idx_ramo_2)
            v_eq2(j) = v_j(idx_ramo_2(end));
        end
    else
        v_eq1(j) = v_stallo_j;
        use_stallo(j) = true;
        v_eq2(j) = v_massima;
    end

    % TIME TO CLIMB
    if j ~= 1
        delta_h = h_vect(j) - h_vect(j-1);
        
        % Quasi-steady
        dt2c(j) = delta_h / max_SEP_current; 
        t2c(j) = t2c(j-1) + dt2c(j); 

        % Unsteady      
        gradV(j) = (v_Vv_massima_inv(j) - v_Vv_massima_inv(j-1)) / delta_h; 
        correction_factor = 1 + v_Vv_massima_inv(j) / g * gradV(j); % correction from the quasi-steady approach
        udt2c(j) = delta_h / (max_SEP_current / correction_factor);
        ut2c(j) = ut2c(j-1) + udt2c(j); 
    else 
        t2c(j) = 0;
        ut2c(j) = 0;
        dt2c(j) = 0;
        udt2c(j) = 0;
        gradV(j) = 0; 
    end
end

% TAS envelope
figure(10);  
hold on;
plot(v_eq1(~use_stallo), h_vect(~use_stallo), '--b', 'LineWidth', 1.5, 'DisplayName', 'Propulsive limitation');
plot(v_eq1(use_stallo), h_vect(use_stallo), '--r', 'LineWidth', 1.5, 'DisplayName', 'Aerodynamic limitation');
plot(v_eq2, h_vect, '-g', 'LineWidth', 1.5, 'DisplayName', 'V_{max}');
plot(v_gamma_max_inv, h_vect, 'om', 'MarkerSize', 6, 'LineWidth', 1.5, 'DisplayName', 'Max angle');
plot(v_Vv_massima_inv, h_vect, 'sc', 'MarkerSize', 6, 'LineWidth', 1.5, 'DisplayName', 'Max rate');
xlim([0, max(v_massima)*1.05]);
xlabel('TAS [m/s]');
ylabel('h [m]');
title('Flight envelope (TAS)');
legend('show', 'Location', 'best');
grid on;
hold off;

% EAS envelope
% TAS -> EAS conversion
v_e_eq1 = v_eq1 .* sqrt(dens_vect / rho0);
v_e_eq2 = v_eq2 .* sqrt(dens_vect / rho0);
v_e_gamma_max = v_gamma_max_inv .* sqrt(dens_vect / rho0);
v_e_Vv_massima = v_Vv_massima_inv .* sqrt(dens_vect / rho0);
v_e_massima = v_massima .* sqrt(dens_vect / rho0); 

figure(11); 
hold on;
plot(v_e_eq1(~use_stallo), h_vect(~use_stallo), '--b', 'LineWidth', 1.5, 'DisplayName', 'Propulsive limitation');
plot(v_e_eq1(use_stallo), h_vect(use_stallo), '--r', 'LineWidth', 1.5, 'DisplayName', 'Aerodynamic limitation');
plot(v_e_eq2, h_vect, '-g', 'LineWidth', 1.5, 'DisplayName', 'V_{max}');
plot(v_e_gamma_max, h_vect, 'om', 'MarkerSize', 6, 'LineWidth', 1.5, 'DisplayName', 'Max angle');
plot(v_e_Vv_massima, h_vect, 'sc', 'MarkerSize', 6, 'LineWidth', 1.5, 'DisplayName', 'Max rate');
xlim([0, max(v_e_massima)*1.05]);
xlabel('EAS [m/s]');
ylabel('h [m]');
title('Flight envelope (EAS)');
legend('show', 'Location', 'best');
grid on;
hold off;

%% Time to climb

% Service ceiling
Vv_target_service = 100/60*0.3048; % rate of climb: 100 ft/min -> m/s
service_ceiling = interp1(Vv_massima, h_vect, Vv_target_service, 'linear');

% Time to climb
% (inverse interpolation, form h to t)
t_operational = interp1(h_vect/1000, t2c/60, operational_ceiling/1000, 'linear'); % steady
t_service = interp1(h_vect/1000, t2c/60, service_ceiling/1000, 'linear');
ut_operational = interp1(h_vect/1000, ut2c/60, operational_ceiling/1000, 'linear'); % unsteady
ut_service = interp1(h_vect/1000, ut2c/60, service_ceiling/1000, 'linear'); 

figure(12);  
hold on;
plot(t2c/60, h_vect/1000, '-b', 'LineWidth', 1.5, 'DisplayName', 'Time to climb (Quasi-Steady)');
plot(ut2c/60, h_vect/1000, '-r', 'LineWidth', 1.5, 'DisplayName', 'Time to climb (Unsteady)');
yline(h_tangenza/1000, 'g-.', 'LineWidth', 1, 'DisplayName', 'Absolute ceiling');
yline(operational_ceiling/1000, '--m', 'LineWidth', 1.5, 'DisplayName', 'Operational Ceiling');
yline(service_ceiling/1000, '--c', 'LineWidth', 1.5, 'DisplayName', 'Service Ceiling');
xline(t_operational, 'm:', 'LineWidth', 1.5,'HandleVisibility', 'off');
xline(t_service, 'c:', 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(ut_operational, 'm:', 'LineWidth', 1.5, 'HandleVisibility', 'off');
xline(ut_service, 'c:', 'LineWidth', 1.5, 'HandleVisibility', 'off');
plot(t_operational, operational_ceiling/1000, 'mo', 'MarkerSize', 4, 'LineWidth', 2, 'HandleVisibility', 'off');
plot(t_service, service_ceiling/1000, 'co', 'MarkerSize', 4, 'LineWidth', 2, 'HandleVisibility', 'off');
plot(ut_operational, operational_ceiling/1000, 'mo', 'MarkerSize', 4, 'LineWidth', 2, 'HandleVisibility', 'off');
plot(ut_service, service_ceiling/1000, 'co', 'MarkerSize', 4, 'LineWidth', 2, 'HandleVisibility', 'off');
xlabel('Time [min]');
ylabel('h [km]');
title('Time to climb');
legend('show', 'Location', 'best');
grid on;
xlim([0,60]);
hold off;

%% Energy Climb 

g = 9.81;
[~, rho_0] = isatm(0);
v_stallo_0 = sqrt((W / S) / (0.5 * rho_0 * cl_max));

% height and speed grid 
h_vect = linspace(0, h_tangenza, 100);
v_vect = linspace(v_stallo_0, v_massima, 500);
[V_grid, H_grid] = meshgrid(v_vect, h_vect);
[~, dens_grid, T_grid] = arrayfun(@isatm, H_grid);
c_grid = sqrt(gamma * R * T_grid);
CL_grid = (W/S)./(0.5*dens_grid.*V_grid.^2);

% mask for valid data
valid_mask = CL_grid <= cl_max & ~isnan(CL_grid);

% SEP 
SEP_grid = NaN(size(V_grid));
CD_base = spline(cl, cd, min(CL_grid, cl_max));
Mach_grid = V_grid./c_grid;
Delta_CD = arrayfun(@(m) spline(Mach_dragrise, Dragrise, min(max(m, min(Mach_dragrise)), max(Mach_dragrise))), Mach_grid);
D_grid = 0.5*dens_grid.*V_grid.^2*S.*(CD_base + Delta_CD);
T_avail = arrayfun(@(h,v) T_interp(h,v), H_grid,V_grid);
SEP_grid(valid_mask) = (T_avail(valid_mask).*V_grid(valid_mask) - D_grid(valid_mask).*V_grid(valid_mask)) / W;

% Tangent points search by finding where the slopes are closer
max_sep_calculated = max(SEP_grid(:));
SEP_levels = linspace(0, max_sep_calculated, 100); 

tangent_points = [];
for target_SEP = SEP_levels
    
    % iso-SEP curves contour
    C = contourc(v_vect, h_vect, SEP_grid, [target_SEP target_SEP]);
    [v_contour, h_contour] = extractContour(C); 

    % iso-SEP slope calculation
    dv = diff(v_contour); % v(i+1)-v(i)
    dh = diff(h_contour); % h(i+1)-h(i)
    zero_dv_mask = dv == 0; % avoid divisions for 0 
    grad = dh(~zero_dv_mask) ./ dv(~zero_dv_mask); % dh/dv

    % A constant speed is assumed along the segment to evaluate the slope difference
    v_center = v_contour(find(~zero_dv_mask) + 1);

    % Find the point where the difference is minimized
    if isempty(grad)
        continue;
    end
    [~, idx] = min(abs(grad + v_center/g)); % energy-height slope = -v/g

    % Find the index on the original vectors dh and dv
    original_idx = find(~zero_dv_mask);
    if idx > 0 && idx <= length(original_idx)
       original_idx_for_point = original_idx(idx);

       % The tangent point is between v_contour(original_idx_for_point) and v_contour(original_idx_for_point+1)
       % the final point of the segment will be the one whose gradiend is closest to the target
       tangent_v = v_contour(original_idx_for_point + 1);
       tangent_h = h_contour(original_idx_for_point + 1);

       % Store the tangent points 
       if isfinite(tangent_v) && isfinite(tangent_h)
            tangent_points = [tangent_points; tangent_v, tangent_h];
       end
    end
end

figure (13)
SEP_levels_plot = [0, 5, 10, 15, 20, 25]; % Livelli da visualizzare
[C, h_contour] = contour(V_grid, H_grid, SEP_grid, SEP_levels_plot, "LabelFormat", "%0.1f m/s", 'LineWidth', 1.8);
clabel(C, h_contour, 'FontSize', 10);
hold on;
plot(tangent_points(:,1), tangent_points(:,2), 'r--', 'LineWidth', 2);
h_standard_plot = plot(v_Vv_massima_inv, h_vect, 'b--', 'LineWidth', 2.5, 'DisplayName', 'Standard Climb Path ');
xlabel('V [m/s]'); 
ylabel('h [m]');
title('Energy Climb');
legend('Iso-SEP', 'Energy Climb', 'Standard Climb');
ylim([0, h_tangenza*1.05]);
xlim([0, v_massima*1.05]);
grid on
hold off

%% Turn 

figure(14)
hold on
grid on

% Parameters
n_values = 1:0.5:5; % load factors
[~, dens_turn, T_turn] = isatm(h_turn);
c = sqrt(gamma * R * T_turn);
v_stallo_turn = sqrt((W / S) / (0.5 * dens_turn * cl_max));
v_vect = linspace(v_stallo_turn, v_massima, 1000);

% Struct to memorize the curves
curves = struct();
for i = 1:length(n_values)
    n = n_values(i);
    
    % turn parameters
    v_stallo_turn = sqrt((W*n/S) / (0.5 * dens_turn * cl_max));
    v_turn = linspace(v_stallo_turn, v_massima, 1000); 
    
    % available thrust 
    Thrust_turn = T_interp(h_turn, v_turn); 
    
    % drag
    D = zeros(size(v_turn));
    for j = 1:length(v_turn)
        CL = (W*n/S) / (0.5 * dens_turn * v_turn(j)^2);
        CD = spline(cl, cd, CL);
        
        Mach_turn = v_turn(j)/c;
        if Mach_turn < min(Mach_dragrise)
            Delta_CD = 0;
        elseif Mach_turn > max(Mach_dragrise)
            Delta_CD = max(Dragrise);
        else
            Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn);
        end
        
        D(j) = 0.5 * dens_turn * v_turn(j)^2 * S * (CD + Delta_CD);
    end
    
    % data is saved in the struct
    curves(i).v = v_turn;
    curves(i).D = D;
    curves(i).n = n;
    curves(i).v_stallo = v_stallo_turn;
    curves(i).D_stallo = D(1);
end

% define load factor limits
n1_curve = curves([curves.n] == 1);
nmax_curve = curves([curves.n] == n_max);

% P1 (n=1 and stall limit)
P1 = [n1_curve.v_stallo, n1_curve.D_stallo];

% P2 (stall limit and available thrust or maximum load factor)
stall_v = [curves.v_stallo];
stall_D = [curves.D_stallo];
[stall_v_sorted, sort_idx] = sort(stall_v);
stall_D_sorted = stall_D(sort_idx);

% thrust is calculated for the range of speeds of the n=n_max curve 
v_range_nmax = linspace(min(nmax_curve.v), max(nmax_curve.v), 1000);
Thrust_nmax = T_interp(h_turn, v_range_nmax);

thrust_fun = @(v) spline(v_turn, Thrust_turn, v);
stall_fun = @(v) spline(stall_v_sorted, stall_D_sorted, v);

% Intersection between stall limit and maximum load factor
P2_stall_nmax = [spline(stall_D_sorted, stall_v_sorted, nmax_curve.D), nmax_curve.D];

% Search for a possible intersection between stall limit and available thrust 
v_intersect = linspace(min(stall_v_sorted), max(stall_v_sorted), 1000);
diff_stall_thrust = stall_fun(v_intersect) - thrust_fun(v_intersect);
sign_changes = find(diff_stall_thrust(1:end-1) .* diff_stall_thrust(2:end) <= 0);
if ~isempty(sign_changes)
    v_int = fzero(@(v) stall_fun(v) - thrust_fun(v), [v_intersect(sign_changes(1)), v_intersect(sign_changes(1)+1)]);
    P2_stall_thrust = [v_int, thrust_fun(v_int)];
else
    P2_stall_thrust = P2_stall_nmax; % If none is found, the load factor intersection is used
end

% If both intersections are found, the one at lower speed is used 
if P2_stall_thrust(1) < P2_stall_nmax(1,1)
    P2 = P2_stall_thrust;
else
    P2 = P2_stall_nmax;
end

% P3 (available thrust and n=n_max)
v_intersect = linspace(min(nmax_curve.v), v_massima , 1000); 
thrust_fun = @(v) spline(v_turn, Thrust_turn, v);
nmax_fun = @(v) spline(nmax_curve.v, nmax_curve.D, v);
diff_fun = nmax_fun(v_intersect) - thrust_fun(v_intersect);
sign_changes = find(diff_fun(1:end-1) .* diff_fun(2:end) <= 0);

P3 = [];
for idx = sign_changes
    v_int = fzero(@(v) nmax_fun(v) - thrust_fun(v), [v_intersect(idx), v_intersect(idx+1)]);
    P3 = [P3; v_int, thrust_fun(v_int)];
end


% P4 (available thrust and n=1)
n1_fun = @(v) spline(n1_curve.v, n1_curve.D, v);
v_intersect_n1 = linspace(min(n1_curve.v), v_massima * 1.1, 1000);
diff_n1_thrust = n1_fun(v_intersect_n1) - thrust_fun(v_intersect_n1);
sign_changes_n1 = find(diff_n1_thrust(1:end-1) .* diff_n1_thrust(2:end) <= 0);

P4 = [];
if ~isempty(sign_changes_n1)
    v_int = fzero(@(v) n1_fun(v) - thrust_fun(v), [v_intersect_n1(sign_changes_n1(1)), v_intersect_n1(sign_changes_n1(1)+1)]);
    P4 = [v_int, thrust_fun(v_int)];
else
    % If no intersection is found, the intersection with v_massima is used
    v_int = v_massima;
    P4 = [v_int, thrust_fun(v_int)];
end

% If P3 is empty, the available thrust curve is used as a limit until P4
if isempty(P3)
    v_thrust_to_P4 = linspace(P2(1), P4(1), 100)';
    thrust_to_P4 = thrust_fun(v_thrust_to_P4);
    P3 = [v_thrust_to_P4(end), thrust_to_P4(end)]; % last point of the thrust curve
else
    % If there are intersections, only the first and last points are stored 
    P3 = [P3(1,:); P3(end,:)];
end

% Defing the fill area
% 1. From P1 to P2: stall line
stall_segment_idx = find(stall_v_sorted >= P1(1) & stall_v_sorted <= P2(1));
stall_segment_v = stall_v_sorted(stall_segment_idx);
stall_segment_D = stall_D_sorted(stall_segment_idx);

% 2. From P2 to P4: minimum between thust and n_max curve
v_upper_segment = linspace(P2(1), P4(1), 100)';
thrust_upper_segment = thrust_fun(v_upper_segment);
nmax_upper_segment = nmax_fun(v_upper_segment);
upper_segment_D = min(thrust_upper_segment, nmax_upper_segment);

% 3. From P4 to P1: n=1 curve 
n1_curve = curves([curves.n] == 1);
v_p4 = P4(1);
D_p4 = P4(2);
v_p1 = P1(1);
D_p1 = P1(2);

idx_n1 = find(n1_curve.v > min(v_p1, v_p4) & n1_curve.v < max(v_p1, v_p4));
v_intermediate = n1_curve.v(idx_n1);
D_intermediate = n1_curve.D(idx_n1);

[n1_segment_v, sort_desc_idx] = sort(v_intermediate, 'descend');
n1_segment_D = D_intermediate(sort_desc_idx);

% fill the defined area
fill_v = [stall_segment_v(:); % P1 -> P2
          v_upper_segment(:); % P2 -> P4 
          n1_segment_v(:)]; % P4 -> P1 
fill_D = [stall_segment_D(:);
          upper_segment_D(:);
          n1_segment_D(:)];

% Plot the filled area
fill_area = fill(fill_v, fill_D, [1 0 0], 'EdgeColor', 'r', 'FaceAlpha', 0.2, 'DisplayName', 'Turn envelope');
hold on;

% Plot the original curves
for i = 1:length(curves)
    if curves(i).n == 1 || curves(i).n == n_max
        plot(curves(i).v, curves(i).D, '-r', 'LineWidth', 2);
    else
        plot(curves(i).v, curves(i).D, '-k', 'LineWidth', 1);
    end
end

% Stall line
h_stall = plot(stall_v_sorted, stall_D_sorted, 'k--', 'LineWidth', 1.5, 'DisplayName', 'Stall limit');

% Available thrust
v_range_plot = linspace(min([curves.v]), max([curves.v]), 1000);
Thrust_plot = T_interp(h_turn, v_range_plot);
h_thrust = plot(v_range_plot, Thrust_plot, '-b', 'LineWidth', 2.5, 'DisplayName', 'Thrust available');

% load factor tags
for i = 1:length(curves)
    text(curves(i).v_stallo+2, curves(i).D_stallo, sprintf('n=%.1f', curves(i).n), 'Color', 'k');
end
xlim([0, max(v_massima)*1.05]);
xlabel('TAS [m/s]', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Drag [N]', 'FontSize', 12, 'FontWeight', 'bold');
title(sprintf('Turn Envelope at h=%d m', h_turn), 'FontSize', 14, 'FontWeight', 'bold');
legend([h_stall, h_thrust, fill_area], 'Location', 'best ');
hold off;

%% Turn performance

% Only the positive branch of the polar is considered
cl_pos = cl(cl >= 0);
cd_pos = cd(cl >= 0);

% v_vect is limited to P4(1), the last speed at which the turn is possible
valid_idx = v_vect <= P4(1);
v_valid = v_vect(valid_idx);
Thrust_turn_valid = Thrust_turn(valid_idx);

% Variables
n_achievable = ones(size(v_valid));
limitation = cell(size(v_valid));
phi_vect = zeros(size(v_valid)); % bank angle [gradi]
R_vect = zeros(size(v_valid)); % turn radius [m]
t_180_vect = zeros(size(v_valid)); % time to 180° [s]

for k = 1:length(v_valid)
    V = v_valid(k);
    C_D_total = Thrust_turn_valid(k) / (0.5 * dens_turn * V^2 * S);
    Mach_turn = V / c;
    if Mach_turn < min(Mach_dragrise)
        Delta_CD = 0; 
    elseif Mach_turn > max(Mach_dragrise)
        Delta_CD = max(Dragrise); 
    else
        Delta_CD = spline(Mach_dragrise, Dragrise, Mach_turn); 
    end

    C_D_polare = C_D_total - Delta_CD;
    % Determine the active limitation: 
    % Hypotesis: aerodynamic limitation
    if C_D_polare > max(cd_pos)
        % Drag outside the scope of the polar
        C_L = max(cl_pos);
        active_limitation = 'aerodynamic';
    else
        C_L = spline(cd_pos, cl_pos, C_D_polare);
        active_limitation = 'propulsive';
    end
    
    % load factor
    n = (0.5 * dens_turn * V^2 * S * C_L) / W;
    
    % the structural limitation is imposed
    if n > n_max
        n = n_max;
        active_limitation = 'structural';
    end
    
    n_achievable(k) = n;
    limitation{k} = active_limitation;

    % turn performance
    phi_vect(k) = acosd(1/n); % bank angle
    R_vect(k) = V^2/(g*sqrt(n^2 - 1)); % turn radius
    omega = V/R_vect(k); % turn rate [rad/s]
    t_180_vect(k) = pi / omega; % time to 180°
end

figure(15)
hold on
grid on

% handle for the legend
h_propulsive = [];
h_aerodynamic = [];
h_structural = [];

% Find the transitions between the limitations
transitions = find(diff([0, strcmp(limitation, 'aerodynamic')]) | diff([0, strcmp(limitation, 'structural')]));
transitions = [transitions, length(v_valid)];

% Plot by switching between limitations
start_idx = 1;
for i = 1:length(transitions)
    end_idx = transitions(i);
    current_lim = limitation{start_idx};
    switch current_lim
        case 'propulsive'
            color = 'b';
            h_propulsive = plot(v_valid(start_idx:end_idx), n_achievable(start_idx:end_idx), color, 'LineWidth', 2, 'DisplayName', 'Propulsive limitation');
        case 'aerodynamic'
            color = 'r';
            h_aerodynamic = plot(v_valid(start_idx:end_idx), n_achievable(start_idx:end_idx), color, 'LineWidth', 2, 'DisplayName', 'Aerodynamic limitation');
        case 'structural'
            color = 'g';
            h_structural = plot(v_valid(start_idx:end_idx), n_achievable(start_idx:end_idx), color, 'LineWidth', 2, 'DisplayName', 'Structural limitation');
    end
    start_idx = end_idx + 1;
end

% structural limit
h_nmax = yline(n_max, '--k', 'LineWidth', 1, 'DisplayName', 'n_{max}');
xlim([0, max(v_massima)*1.05]);
ylim([1, n_max*1.05]);
xlabel('TAS [m/s]', 'FontSize', 12, 'FontWeight', 'bold')
ylabel('Load factor', 'FontSize', 12, 'FontWeight', 'bold')
title(sprintf('Coordinated turn: load factor at h=%d m', h_turn), 'FontSize', 14, 'FontWeight', 'bold')
handles = [h_propulsive, h_aerodynamic, h_structural, h_nmax];
legend(handles, 'Location', 'best')
hold off
figure(16)

% bank angle
hold on
grid on
plot(v_valid, phi_vect, 'g', 'LineWidth', 2)
xlim([0, max(v_massima)*1.05])
xlabel('TAS [m/s]', 'FontSize', 12, 'FontWeight', 'bold')
ylabel('Bank angle [deg]', 'FontWeight', 'bold')
title(sprintf('Coordinated turn: bank angle at h=%d m', h_turn), 'FontSize', 14)
ylim([0 90])
hold off

% turn radius
figure(17)
hold on
grid on
plot(v_valid, R_vect, 'r', 'LineWidth', 2)
xlim([0, max(v_massima)*1.05])
xlabel('TAS [m/s]', 'FontSize', 12, 'FontWeight', 'bold')
ylabel('Turn radius [m]', 'FontWeight', 'bold')
title(sprintf('Coordinated turn: turn radius at h=%d m', h_turn), 'FontSize', 14)
ylim([0, 5000])
hold off

v_valid_eas = v_valid .* sqrt(dens_turn / rho0);
v_massima_eas = v_massima .* sqrt(dens_turn / rho0);

% time to 180°
figure(18)
hold on
grid on
plot(v_valid_eas, t_180_vect, 'm', 'LineWidth', 2)
xlim([0, max(v_massima_eas)*1.05])
xlabel('EAS [m/s]', 'FontWeight', 'bold')
ylabel('Time for 180° turn [s]', 'FontWeight', 'bold')
title(sprintf('Coordinated turn: time to turn at h=%d m', h_turn), 'FontSize', 14)
ylim([0, 150])
hold off


%% Turn performance behaviour with height

h_vect = linspace(0, h_tangenza, 100); % analyzed heights

% TAS variables
V_minR = NaN(size(h_vect)); 
min_R = NaN(size(h_vect));  
V_mint = NaN(size(h_vect)); 
min_t = NaN(size(h_vect));  
max_Phi = NaN(size(h_vect)); 
V_maxPhi_lower = NaN(size(h_vect));
V_maxPhi_upper = NaN(size(h_vect));

% EAS variables
V_minR_EAS = NaN(size(h_vect));
V_mint_EAS = NaN(size(h_vect));
V_maxPhi_lower_EAS = NaN(size(h_vect));
V_maxPhi_upper_EAS = NaN(size(h_vect));

% desity for the TAS -> EAS conversion
dens_vect = NaN(size(h_vect));

for h_idx = 1:length(h_vect)
    h = h_vect(h_idx);
    [~, dens, T] = isatm(h);
    dens_vect(h_idx) = dens; 
    c = sqrt(gamma * R * T); 

    % speed range at current height
    v_stallo_n1 = sqrt((W/S)/(0.5*dens*cl_max)); 
    v_vect = linspace(v_stallo_n1, v_eq2(h_idx), 300); 

    % temporary variables
    R_temp = NaN(size(v_vect));
    t_temp = NaN(size(v_vect));
    Phi_temp = NaN(size(v_vect));
    n_temp = NaN(size(v_vect));

    for v_idx = 1:length(v_vect)
        V = v_vect(v_idx);          
        
        % The dragrise is excluded
        C_D_totale_turn = T_interp(h, V) / (0.5 * dens * V^2 * S);
        Mach_turn = V / c;
        Delta_C_D = spline(Mach_dragrise, Dragrise, min(max(Mach_turn, min(Mach_dragrise)), max(Mach_dragrise)));
        C_D_polare = C_D_totale_turn - Delta_C_D;
        
        [min_cd_turn, idx_min_cd_turn] = min(cd_pos);
        CL_min_turn = cl_pos(idx_min_cd_turn);
        
        if C_D_polare < min_cd_turn
            % Case 1: excess of thrust
            CL_turn = CL_min_turn;
        elseif C_D_polare > cd_pos(end) 
            % Case 2: not enough thrust
            CL_turn = cl_max;
        else
            % Case 3: C_D_polare found from thrust is in the polar's range
            CL_interp = spline(cd_pos, cl_pos, C_D_polare);
            CL_turn = CL_interp;
        end
        
        % theorethical factor
        n_teorico = (0.5 * dens * V^2 * S * CL_turn) / W;
        
        % the structural limit is imposed 
        n_temp(v_idx)= min(n_teorico, n_max);
        
        % R_temp, t_temp, Phi_temp calculated from n_temp(v_idx)
        if n_temp(v_idx) > 1.0001
            Phi_temp(v_idx) = acosd(1/n_temp(v_idx));
            R_temp(v_idx) = V^2 / (g * sqrt(n_temp(v_idx)^2 - 1));
            omega_val = g * sqrt(n_temp(v_idx)^2 - 1) / V;
            if omega_val < 1e-9 || isnan(omega_val) || isinf(omega_val)
                t_temp(v_idx) = Inf;
            else
                t_temp(v_idx) = pi / omega_val;
            end
        else
            Phi_temp(v_idx) = 0;
            R_temp(v_idx) = Inf;
            t_temp(v_idx) = Inf;
        end
    end

    % maximum performance TAS
    valid_R = ~isnan(R_temp) & isfinite(R_temp);
    if any(valid_R)
        R_temp_valid = R_temp(valid_R);
        v_vect_valid_R = v_vect(valid_R);
        [min_R_val, idx_minR_valid] = min(R_temp_valid);
        min_R(h_idx) = min_R_val;
        V_minR(h_idx) = v_vect_valid_R(idx_minR_valid);
    end
    
    valid_t = ~isnan(t_temp) & isfinite(t_temp);
    if any(valid_t)
        t_temp_valid = t_temp(valid_t);
        v_vect_valid_t = v_vect(valid_t);
        [min_t_val, idx_mint_valid] = min(t_temp_valid);
         min_t(h_idx) = min_t_val;
        V_mint(h_idx) = v_vect_valid_t(idx_mint_valid);
    end
    
    % find the maximum bank angle
    valid_n = ~isnan(n_temp) & n_temp > 1;
    if any(valid_n)
        max_n = max(n_temp(valid_n));
        max_Phi(h_idx) = acosd(1/max_n);
        
        % find all the speeds for which n ≈ max_n
        tol = 1e-10;
        idx_max = find(abs(n_temp - max_n) < tol);
        
        if ~isempty(idx_max)
            V_maxPhi = v_vect(idx_max);
            V_maxPhi_lower(h_idx) = min(V_maxPhi);
            V_maxPhi_upper(h_idx) = max(V_maxPhi);
        end
    end
    
    % EAS equivalents
    if ~isnan(V_minR(h_idx))
        V_minR_EAS(h_idx) = V_minR(h_idx) * sqrt(dens/rho0);
    end
    if ~isnan(V_mint(h_idx))
        V_mint_EAS(h_idx) = V_mint(h_idx) * sqrt(dens/rho0);
    end
    if ~isnan(V_maxPhi_lower(h_idx))
        V_maxPhi_lower_EAS(h_idx) = V_maxPhi_lower(h_idx) * sqrt(dens/rho0);
        V_maxPhi_upper_EAS(h_idx) = V_maxPhi_upper(h_idx) * sqrt(dens/rho0);
    end
end

% TAS
figure(19)
hold on 
grid on 
% Performance in TAS
p1 = plot(V_minR, h_vect, ':r', 'LineWidth', 2, 'DisplayName', 'Minimum radius (TAS)');
p2 = plot(V_mint, h_vect, '-.b', 'LineWidth', 2, 'DisplayName', 'Minimum time to turn (TAS)');
p3 = plot(V_maxPhi_lower, h_vect, '-g', 'LineWidth', 2, 'DisplayName', 'Maximum bank angle (TAS)');
plot(V_maxPhi_upper, h_vect, '-g', 'LineWidth', 2);
% flight envelope
p4 = plot(v_eq1, h_vect, '--k', 'LineWidth', 0.5, 'DisplayName', 'Vmin');
p5 = plot(v_eq2, h_vect, '--k', 'LineWidth', 1.5, 'DisplayName', 'Vmax');
xlim([0, max(v_massima)*1.05])
xlabel('TAS [m/s]', 'FontWeight', 'bold');
ylabel('h [m]', 'FontWeight', 'bold');
title('Turn performance TAS', 'FontSize', 12);
legend([p1 p2 p3 p4 p5], 'Location', 'best');
hold off;

% EAS
figure(20)
hold on 
grid on
% Performance in EAS
p1 = plot(V_minR_EAS, h_vect, ':r', 'LineWidth', 2, 'DisplayName', 'Minimum radius (EAS)');
p2 = plot(V_mint_EAS, h_vect, '-.b', 'LineWidth', 2, 'DisplayName', 'Minimo time to turn (EAS)');
p3 = plot(V_maxPhi_lower_EAS, h_vect, '-g', 'LineWidth', 2, 'DisplayName', 'Maximum bank angle (EAS)');
plot(V_maxPhi_upper_EAS, h_vect, '-g', 'LineWidth', 2);
% EAS flight envelope
v_e_eq1 = v_eq1 .* sqrt(dens_vect / rho0);
v_e_eq2 = v_eq2 .* sqrt(dens_vect / rho0);
p4 = plot(v_e_eq1, h_vect, '--k', 'LineWidth', 0.5, 'DisplayName', 'Vmin');
p5 = plot(v_e_eq2, h_vect, '--k', 'LineWidth', 1.5, 'DisplayName', 'Vmax');
xlim([0, max(v_massima)*1.05])
xlabel('EAS [m/s]', 'FontWeight', 'bold');
ylabel('h [m]', 'FontWeight', 'bold');
title('Turn performance EAS', 'FontSize', 12);
legend([p1 p2 p3 p4 p5], 'Location', 'best');
hold off;

%% Glide

[~, dens_glide, T_glide] = isatm(h_glide);
c = sqrt(gamma * R * T_glide);
cl_glide = linspace(0, cl_max, 1000);
cd_glide = spline(cl, cd, cl_glide);

% Dive speed for cl_glide = 0 (no drag-rise)
cd_at_cl_zero = spline(cl, cd, 0);
V_dive = sqrt(W / (0.5 * dens_glide * S * cd_at_cl_zero));

E_glide = zeros(size(cl_glide)); 
glide_angle = zeros(size(cl_glide)); 
V_glide = zeros(size(cl_glide)); 
V_horizontal = zeros(size(cl_glide)); 
V_vertical = zeros(size(cl_glide));

V_glide_dragrise = zeros(size(cl_glide));
glide_angle_dragrise = zeros(size(cl_glide));
V_horizontal_dragrise = zeros(size(cl_glide));
V_vertical_dragrise = zeros(size(cl_glide));
cd_glide_dragrise = zeros(size(cl_glide));

% odograph without drag-rise 
for i = 1:length(cl_glide)
    if cl_glide(i) == 0
        E_glide(i) = 0;
        glide_angle(i) = -pi/2;
        V_glide(i) = V_dive;
        V_horizontal(i) = 0;
        V_vertical(i) = -V_glide(i);
    else
        E_glide(i) = cl_glide(i) / cd_glide(i);
        glide_angle(i) = -atan(1/E_glide(i));
        V_glide(i) = sqrt((cos(glide_angle(i)) * W) / (0.5 * dens_glide * S * cl_glide(i)));
        V_horizontal(i) = V_glide(i) * cos(glide_angle(i));
        V_vertical(i) = V_glide(i) * sin(glide_angle(i));
    end
end

% Odograph with drag-rise

% solver options
options = optimoptions('fsolve', ...
    'Display', 'off', ... % hides fsolve's output
    'TolFun', 1e-8, ... % Tollerance on the fuction
    'TolX', 1e-8, ... % Tollerance on the variables
    'MaxIterations', 1000, ... % Maximum number of iterations
    'MaxFunEvals', 1000, ... % Maximum number of evaluations of the fuction
    'Algorithm', 'trust-region-reflective');

% the previous solution is initialized for continuity
V_prev = V_dive; % dive speed
gamma_prev = -pi/2; % dive angle

for i = 1:length(cl_glide)
    CL = cl_glide(i);
    CD_base = spline(cl, cd, CL); % base drag, without drag-rise

    % use of the previous solution for continuity
    x0 = [V_prev, gamma_prev];
    
    % Non-linear equations
    eqns = @(x) [...
        0.5 * dens_glide * x(1)^2 * S * CL - W * cos(x(2)); % Vertical equilibrium
        0.5 * dens_glide * x(1)^2 * S * (CD_base + spline(Mach_dragrise, Dragrise, min(max(x(1)/c, min(Mach_dragrise)), max(Mach_dragrise)))) + W * sin(x(2)) % Horizontal equilibrium
    ];
    
    % Resolution using fsolve
    sol = fsolve(eqns, x0, options);
    
    % results
    V_glide_dragrise(i) = sol(1);
    glide_angle_dragrise(i) = sol(2);
    
    % the previous solution is updated
    V_prev = sol(1);
    gamma_prev = sol(2);
        
    % speed components
    V_horizontal_dragrise(i) = V_glide_dragrise(i) * cos(glide_angle_dragrise(i));
    V_vertical_dragrise(i) = V_glide_dragrise(i) * sin(glide_angle_dragrise(i));
end

figure(21)
hold on
grid on
plot(V_horizontal, V_vertical, '--b', 'LineWidth', 2, 'DisplayName', 'no dragrise')
plot(V_horizontal_dragrise, V_vertical_dragrise, '-r', 'LineWidth', 2, 'DisplayName', 'with dragrise')
xlabel('Horizontal velocity [m/s]', 'FontWeight', 'bold');
ylabel('Vertical velocity [m/s]', 'FontWeight', 'bold');
title('Odograph', 'FontSize', 12);
legend('Location', 'best');
hold off;

%% Flapped Polar
% Data from " Roskam, Airplane Design, Roskam Aviation, 1985"

K_freccia= (1-0.08*(cos(angolo_freccia))^2)*(cos(angolo_freccia))^(3/4);

dCl_airf=Cl_delta_flap*delta_flap*K_primo; % airfoil lift increase
dCl_max=dCl_airf*Swf_S*K_freccia; % lift increment

dCd_airf=dCd_2d*cos(angolo_freccia)*Swf_S; % isolated airfoil increment

dCd_ind=K_ind^2*dCl_max^2*cos(angolo_freccia); % increment induced by lift

dCd_interf=K_int*dCd_airf; % interference drag

dCd=dCd_airf+dCd_ind+dCd_interf+dCd_gear; % drag increment;

cl_t=Polar(1, :);
cd_t=Polar(2, :);

cl_f=cl_t+dCl_max; 
cd_f=cd_t+dCd;

%% Take off and ground run

[~, dens_to, ~] = isatm(h_airport); 

[cl_f_max, i_cl_f_max]=max(cl_f); % stall
cl_f_to=cl_f(1:i_cl_f_max); 
cd_f_to=cd_f(1:i_cl_f_max);

cl_f_pos = cl_f_to(cl_f_to >= 0);
cd_f_pos = cd_f_to(cl_f_to >= 0);
CL_f = linspace(0,cl_f_max,100);
CD_f = spline(cl_f_pos, cd_f_pos, CL_f);

[C_D_L_opt, i_C_D_L_opt]=min(CD_f-mu_runway*CL_f);
CL_f_opt=CL_f(i_C_D_L_opt);
CD_f_opt=CD_f(i_C_D_L_opt);

V_stall=sqrt((W / S) / (0.5 * dens_to * cl_f_max));
V_rotation=sqrt(1.1)*V_stall;
eta_in=V_in/V_rotation;

% Ground run
Sg_fun=@(eta) eta./(0.5*dens_to*1/1.1*cl_f_max*(T_interp(0,eta*V_rotation)/W-(mu_runway+psi))-0.5*dens_to*eta.^2*(C_D_L_opt)); % ground run
Sg=integral(Sg_fun,eta_in,1);
Sg=Sg*(W/S)/g;

% trimmed polar
figure(22)
grid on  
hold on
plot(cd_t, cl_t, 'r--', 'LineWidth', 2, 'DisplayName', 'Clean'); 
plot(cd_f, cl_f, 'b', 'LineWidth', 2, 'DisplayName', 'Flap 15 deg');
plot(CD_f_opt,CL_f_opt,'g^', 'LineWidth', 2, 'DisplayName', 'Optimal take off condition');
xlabel('C_D');
ylabel('C_L');
title('Flapped Polar');
legend('Location', 'best');
hold off

% Effective drag
figure(23)
grid on  
hold on
plot(CL_f, CD_f-mu_runway*CL_f, 'b', 'LineWidth', 2, 'DisplayName', 'CD-mu*CL (mu=0.05)'); 
plot(CL_f_opt,C_D_L_opt,'g^', 'LineWidth', 2, 'DisplayName', 'Optimal take off condition');
xlabel('C_L');
ylabel('C_D-mu*C_L (mu=0.05)'); % reduction indrag as lift increases
title('Effective drag');
legend('Location', 'best');
hold off

%% Take off analysis

V_to_vect=linspace(0,V_rotation,100);
Sg_AEO=zeros(size(V_to_vect));
Sg_OEI=zeros(size(V_to_vect));
Sg_STOP=zeros(size(V_to_vect));

for i=1:length(V_to_vect)
% AEO (all engines operative)
Sg_fun_AEO=@(eta) eta./(0.5*dens_to*1/1.1*cl_f_max*(T_interp(0,eta*V_rotation)/W-(mu_runway+psi))-0.5*dens_to*eta.^2*(C_D_L_opt));
Sg_AEO(i)=-(W/S)/g*integral(Sg_fun_AEO,0,V_to_vect(i)/V_rotation);

% OEI (one engine operative)
Sg_fun_OEI=@(eta) eta./(0.5*dens_to*1/1.1*cl_f_max*(0.5*T_interp(0,eta*V_rotation)/W-(mu_runway+psi))-0.5*dens_to*eta.^2*(C_D_L_opt));
Sg_OEI(i)=(W/S)/g*integral(Sg_fun_OEI,0,V_rotation/V_rotation)-(W/S)/g*integral(Sg_fun_OEI,0,V_to_vect(i)/V_rotation);

% STOP (aborted take-off)
Sg_fun_STOP=@(eta) eta./(0.5*dens_to*1/1.1*cl_f_max*(0*T_interp(0,eta*V_rotation)/W-(mu_brakes+psi))-0.5*dens_to*eta.^2*(C_D_L_opt));
Sg_STOP(i)=(W/S)/g*integral(Sg_fun_STOP,V_to_vect(i)/V_rotation,0);
end

% Finds the index at which Sg_OEI and Sg_STOP are closest
[min_diff, idx_V1] = min(abs(Sg_OEI - Sg_STOP));

V1_estimated = V_to_vect(idx_V1);
Balanced_Field_Length = Sg_OEI(idx_V1)+abs(Sg_AEO(idx_V1));

figure(24)
grid on  
hold on
plot(V_to_vect, Sg_AEO, 'b', 'LineWidth', 2, 'DisplayName', 'AEO'); 
plot(V_to_vect, Sg_OEI, 'r--', 'LineWidth', 2, 'DisplayName', 'OEI'); 
plot(V_to_vect, Sg_STOP, 'g', 'LineWidth', 2, 'DisplayName', 'STOP'); 
plot(V1_estimated, Sg_OEI(idx_V1), 'ko', 'MarkerSize', 5, 'LineWidth', 2, 'DisplayName', 'V1');
plot([V1_estimated, V1_estimated], [Sg_AEO(idx_V1), Sg_OEI(idx_V1)], 'k:', 'LineWidth', 1.5, 'DisplayName', 'BFL');
text(V1_estimated, Sg_OEI(idx_V1), sprintf('  V1=%.1f m/s\n  BFL=%.1f m', V1_estimated, Balanced_Field_Length),'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
xlabel('Speed [m/s]');
ylabel('Ground run [m]'); 
title('Take off analysis');
legend('Location', 'best');
hold off

%% Comparison

% W/S: % low: for better take-off and landing performnce
       % high: for better performance at higher speeds
% T/W: % low: is usually correlated to optimized aerodynamics, but worse climb performance
       % high: better acceleration and climb performance

% Bombardier Global 6500
MTOW_6500=45132; % kg
S_6500=94.9; % m^2
T_6500=134.6*10^3; % N
Wing_load_6500=MTOW_6500/S_6500; % kg/m^2
T_to_W_6500=T_6500/(MTOW_6500*g); 

% Bombardier Global 5500
% same engine and wings, but shorter and with reduced range
MTOW_5500=41731; % kg
S_5500=94.9; % m^2
T_5500=134.6*10^3; % N
Wing_load_5500=MTOW_5500/S_5500; % kg/m^2
T_to_W_5500=T_5500/(MTOW_5500*g); 

% Bombardier Global 7500
% bigger and more powerful, increased range
MTOW_7500=52095; % kg
S_7500=116.9; % m^2
T_7500=166.4*10^3; % N
Wing_load_7500=MTOW_7500/S_7500; % kg/m^2
T_to_W_7500=T_7500/(MTOW_7500*g); 

% Gulfstream G650ER
% direct competitor
MTOW_G650ER=46992; % kg
S_G650ER=119.2; % m^2
T_G650ER=150.4*10^3; % N
Wing_load_G650ER=MTOW_G650ER/S_G650ER; % kg/m^2
T_to_W_G650ER=T_G650ER/(MTOW_G650ER*g); 

% Gulfstream G700
% developed from the G650
MTOW_G700=48807; % kg
S_G700=119.2; % m^2
T_G700=162.4*10^3; % N
Wing_load_G700=MTOW_G700/S_G700; % kg/m^2
T_to_W_G700=T_G700/(MTOW_G700*g);

% Gulfstream G800
% successor of the G650ER. Same wings and engine as the G700, but shorter and with increased range
MTOW_G800=47899; % kg
S_G800=119.2; % m^2
T_G800=162.4*10^3; % N
Wing_load_G800=MTOW_G800/S_G800; % kg/m^2
T_to_W_G800=T_G800/(MTOW_G800*g); 

% Gulfstream G550
% older plane, but one of the most sold 
MTOW_G550=41227; % kg
S_G550=105.6; % m^2
T_G550=136.8*10^3; % N
Wing_load_G550=MTOW_G550/S_G550; % kg/m^2
T_to_W_G550=T_G550/(MTOW_G550*g); 

% Gulfstream G600
% a newer generation of the G550 family
MTOW_G600=42910; % kg
S_G600=105.9; % m^2
T_G600=139.4*10^3; % N
Wing_load_G600=MTOW_G600/S_G600; % kg/m^2
T_to_W_G600=T_G600/(MTOW_G600*g); 

% Dassault Falcon 7X
% trijet, known for being the first completely fly-by-wire business jet
MTOW_7X=31751; % kg
S_7X=70.7; % m^2
T_7X=85.4*10^3; % N
Wing_load_7X=MTOW_7X/S_7X; % kg/m^2
T_to_W_7X=T_7X/(MTOW_7X*g); 

% Dassault Falcon 8X
% one of the few trijets still in production. It's an imporved version of the 7X
MTOW_8X=33113; % kg
S_8X=70.7; % m^2
T_8X=89.7*10^3; % N
Wing_load_8X=MTOW_8X/S_8X; % kg/m^2
T_to_W_8X=T_8X/(MTOW_8X*g); 

% Dassault Falcon 6X
% latest generation widebody business jet
MTOW_6X=35135; % kg
S_6X=72.4; % m^2
T_6X=119.8*10^3; % N
Wing_load_6X=MTOW_6X/S_6X; % kg/m^2
T_to_W_6X=T_6X/(MTOW_6X*g); 

% Dassault Falcon 10X
% still in developement. It will be competing with the Global 7500 and the G800 
MTOW_10X=52183; % kg
S_10X=110; % m^2
T_10X=162.4*10^3; % N
Wing_load_10X=MTOW_10X/S_10X; % kg/m^2
T_to_W_10X=T_10X/(MTOW_10X*g); 

wing_loading = [Wing_load_6500 Wing_load_5500 Wing_load_7500 Wing_load_G650ER Wing_load_G700 Wing_load_G800 Wing_load_G550 Wing_load_G600 Wing_load_7X Wing_load_8X Wing_load_6X Wing_load_10X]; 
thrust_to_weight = [T_to_W_6500 T_to_W_5500 T_to_W_7500 T_to_W_G650ER T_to_W_G700 T_to_W_G800 T_to_W_G550 T_to_W_G600 T_to_W_7X T_to_W_8X T_to_W_6X T_to_W_10X]; 
aircraft_labels = {'Global 6500', 'Global 5500', 'Global 7500', 'G650ER', 'G700', 'G800', 'G550', 'G600', 'Falcon 7X', 'Falcon 8X', 'Falcon 6X', 'Falcon 10X'}; 

figure(25)
grid on  
hold on
% Scatter plot
scatter(wing_loading, thrust_to_weight, 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r'); 
for i = 1:length(aircraft_labels)
    text(wing_loading(i) +0.5, thrust_to_weight(i), aircraft_labels{i}, 'FontSize', 8); % Offset text slightly
end
xlabel('Wing loading [kg/m^2]');
ylabel('Thrust-to-weight ratio [-]'); 
title('Aircraft Performance comparison');
hold off

%% Support functions

function [x, y] = extractContour(C)
% estracts and orders the points of the conotour
x = []; 
y = [];

if size(C,2) < 2, return; 
end

i = 1;

while i < size(C,2) % number of colums

n_points = C(2,i); % number of points in the segment

if (i + n_points) > size(C,2), break; 
end
segment_x = C(1, i+1:i+n_points);
segment_y = C(2, i+1:i+n_points);
% Sort for ascending x values
[segment_x, sort_idx] = sort(segment_x);
segment_y = segment_y(sort_idx);
x = [x, segment_x];
y = [y, segment_y];
i = i + n_points + 1;
end
end